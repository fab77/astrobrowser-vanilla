class InputPanelView {

}

